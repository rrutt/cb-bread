(function () {
    'use strict';

    app.controller('DashboardCtrl', function ($rootScope) {
        $rootScope.breadcrumb.items = [];
    });
})();